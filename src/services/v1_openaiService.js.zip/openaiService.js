// src/services/openaiService.js — Multi‑Level Engagement AI Teacher v2
// Author: ChatGPT (2025-10-14)
// Description: Drop‑in replacement for the previous openaiService.js
//  - Multi‑level engagement (Warm‑up → Core → Challenge → Re‑engage → Wrap‑up)
//  - Anti‑loop detection + redirection (prompt + code safeguards)
//  - Topic‑aware, child‑safe, short sentences (≤10 words)
//  - Dynamic voice/style selection for TTS based on engagement state
//  - Backward compatible exports: getOpenAIResponse, getOpenAIResponseV2, helpers

require('dotenv').config();
const OpenAI = require('openai');

// ————————————————————————————————————————————————————————————————————————————
// Initialization (lazy)
// ————————————————————————————————————————————————————————————————————————————
let openai = null;
const initializeOpenAI = () => {
  if (!openai) {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY environment variable is required');
    }
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openai;
};

// ————————————————————————————————————————————————————————————————————————————
// Multi‑Level Engagement Model
// Levels: WARM_UP, CORE, CHALLENGE, REENGAGE, WRAP_UP
// We infer the next level from the last few user turns + special flags.
// ————————————————————————————————————————————————————————————————————————————
const ENGAGEMENT_LEVEL = {
  WARM_UP: 'WARM_UP',
  CORE: 'CORE',
  CHALLENGE: 'CHALLENGE',
  REENGAGE: 'REENGAGE',
  WRAP_UP: 'WRAP_UP',
};

// Heuristics to detect repetition and engagement
const normalize = (s = '') => s.trim().toLowerCase();
const SIMPLIFY_MAP = [
  ['how are you', 'how are you'],
  ["hi", "hi"],
  ["hello", "hello"],
  ["ok", "ok"],
  ["okay", "ok"],
  ["yes", "yes"],
];

const simplify = (s = '') => {
  const n = normalize(s);
  for (const [key, val] of SIMPLIFY_MAP) {
    if (n === key) return val;
  }
  return n;
};

const isRepeatWithin = (message, history, lookback = 3) => {
  const msg = simplify(message);
  const lastUser = history
    .filter(m => m.sender === 'user')
    .slice(-lookback)
    .map(m => simplify(m.text));
  return lastUser.includes(msg);
};

const countSocialSmallTalk = (history, lookback = 6) => {
  const smallTalkSet = new Set(['hi','hello','how are you','ok','yes']);
  return history
    .filter(m => m.sender === 'user')
    .slice(-lookback)
    .map(m => simplify(m.text))
    .filter(t => smallTalkSet.has(t)).length;
};

const estimateEngagementLevel = ({ message, chatHistory, isAutoPrompt }) => {
  // If auto-prompt (idle 30s), force REENGAGE
  if (isAutoPrompt) return ENGAGEMENT_LEVEL.REENGAGE;

  // If the student repeats trivial phrases → REENGAGE
  if (isRepeatWithin(message, chatHistory, 3)) return ENGAGEMENT_LEVEL.REENGAGE;

  // If the conversation just started or had many small-talk lines → WARM_UP
  const smallTalkCount = countSocialSmallTalk(chatHistory);
  if (chatHistory.length < 3 || smallTalkCount >= 2) return ENGAGEMENT_LEVEL.WARM_UP;

  // Otherwise alternate CORE and CHALLENGE to keep variety
  const lastAssistant = chatHistory.filter(m => m.sender !== 'user').slice(-1)[0]?.text || '';
  const lastTag = /\[LEVEL:([A-Z_]+)\]/.exec(lastAssistant)?.[1] || '';
  if (lastTag === ENGAGEMENT_LEVEL.CORE) return ENGAGEMENT_LEVEL.CHALLENGE;
  if (lastTag === ENGAGEMENT_LEVEL.CHALLENGE) return ENGAGEMENT_LEVEL.CORE;

  return ENGAGEMENT_LEVEL.CORE;
};

// Dynamic voice selection by level (you can map to your TTS voices)
const VOICE_PRESETS = {
  [ENGAGEMENT_LEVEL.WARM_UP]:   { voice: 'breeze',   style: 'soft-friendly' },
  [ENGAGEMENT_LEVEL.CORE]:      { voice: 'alloy',    style: 'clear-slow' },
  [ENGAGEMENT_LEVEL.CHALLENGE]: { voice: 'verse',    style: 'energetic' },
  [ENGAGEMENT_LEVEL.REENGAGE]:  { voice: 'sparkle',  style: 'playful' },
  [ENGAGEMENT_LEVEL.WRAP_UP]:   { voice: 'alloy',    style: 'warm-summary' },
};

const pickVoiceForLevel = (level) => VOICE_PRESETS[level] || VOICE_PRESETS[ENGAGEMENT_LEVEL.CORE];

// ————————————————————————————————————————————————————————————————————————————
// Topics & Prompts (now with ANTI‑LOOP RULES and SESSION STATE injection)
// ————————————————————————————————————————————————————————————————————————————
const ANTI_LOOP_RULES = `
ANTI-LOOP RULES (very important):
- Detect repetition: if the student's message is the same or very similar to any of the last 3 student turns (e.g., “hi”, “hello”, “how are you”, “ok”, “yes”), do NOT answer with the same social reply again.
- Never ask “How are you?” more than once per session.
- Acknowledge briefly (≤6 words), then redirect to a micro-task tied to the current topic.
- Use one of these redirections (vary them):
  1) Teach 1 tiny point (≤10 words) + “Repeat after me: …”
  2) Mini choice with 2–3 options (A/B/C) and emojis.
  3) Quick game: “Say 2 words about …”
- Give a concrete, answerable task. Avoid open questions. End with a task.
- Do not repeat the same sentence twice in a row. If you just used a pattern, pick a different pattern next time.
`;

const BASE_RULES = `
You are a kind, playful English teacher for Vietnamese kids aged 6–11.
Use short, simple sentences (≤10 words). Speak slowly.
Explain clearly like teaching a beginner.
Focus on daily grammar, pronunciation, and Cambridge Starters/Movers content.
Warm, encouraging tone — never robotic. Use light emojis occasionally (😊🎲🎵).

CRITICAL: Always check grammar first.
1) If wrong → correct gently, explain briefly.
2) Ask the student to repeat.
3) Continue only after they understand.

Be proactive: suggest topic activities, mini-games, songs/dialogues.
Repeat key vocabulary naturally. End each reply with a short task.
Use 1–2 short sentences per reply (≤20 words total).
`;

const LEVEL_INSTRUCTIONS = `
LEVEL BEHAVIOR GUIDE:
- [LEVEL:WARM_UP] Greet briefly. Teach 1 tiny point. Give an easy task.
- [LEVEL:CORE] Practice target vocab/grammar. One correction max. Give a clear task.
- [LEVEL:CHALLENGE] Slightly harder task (fill-the-blank, A/B/C). Keep it fun.
- [LEVEL:REENGAGE] Very short, playful line. Immediate mini-game. No open questions.
- [LEVEL:WRAP_UP] Praise + 1-sentence summary. Tiny exit task if time.
`;

// Topic templates (kept from previous version but enriched)
const TOPIC_PROMPTS = {
  'colors': {
    ageRange: '6-8',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Colors — red, blue, green, yellow, orange, purple, pink, black.`
  },
  'family': {
    ageRange: '6-9',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Family — mother, father, sister, brother, grandmother, grandfather, baby.`
  },
  'food': {
    ageRange: '6-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Food — apple, banana, bread, milk, water, cake, pizza, rice.`
  },
  'numbers': {
    ageRange: '6-8',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Numbers — 1 to 20, basic math.`
  },
  'body-parts': {
    ageRange: '7-10',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Body Parts — head, eyes, nose, mouth, hands, feet, ears, legs.`
  },
  'clothes': {
    ageRange: '7-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Clothes — shirt, pants, dress, shoes, hat, socks, jacket, skirt.`
  },
  'weather': {
    ageRange: '8-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Weather — sunny, rainy, cloudy, windy, hot, cold, warm, cool.`
  },
  'school': {
    ageRange: '6-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: School — teacher, student, book, pencil, desk, chair, classroom, playground.`
  },
  'toys': {
    ageRange: '6-9',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Toys — doll, ball, car, game, puzzle, blocks, teddy bear.`
  },
  'animals': {
    ageRange: '6-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: Animals — names, sounds, habitats, actions (run, fly, swim).`
  },
  'general-speaking': {
    ageRange: '6-11',
    prompt: `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}\n\nBe flexible with everyday conversations. Keep variety and fun.\n\nStudent:\n- Name: {{name}}\n- Age: {{age}}\n\nTopic: General Speaking — everyday conversations and speaking practice.`
  }
};

const FOLLOW_UP_PROMPTS = {
  'colors': 'Keep teaching Colors with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'family': 'Keep teaching Family with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'food': 'Keep teaching Food with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'numbers': 'Keep teaching Numbers with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'body-parts': 'Keep teaching Body Parts. Apply ANTI-LOOP RULES. End with a clear task.',
  'clothes': 'Keep teaching Clothes with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'weather': 'Keep teaching Weather with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'school': 'Keep teaching School with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'toys': 'Keep teaching Toys with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'animals': 'Keep teaching Animals with variety. Apply ANTI-LOOP RULES. End with a clear task.',
  'general-speaking': 'Continue as the playful teacher. Apply ANTI-LOOP RULES. Do not repeat social replies. End with a task.'
};

// Helpers
const replacePromptPlaceholders = (prompt, userInfo) =>
  prompt.replace(/{{name}}/g, userInfo?.name || 'Student').replace(/{{age}}/g, userInfo?.age || 'Unknown');

const getTopicId = (topic) => {
  if (!topic) return null;
  return topic.id || topic.title?.toLowerCase().replace(/\s+/g, '-') || null;
};

// Build session state context to help the model avoid loops
const buildSessionStateBlock = (chatHistory = []) => {
  const recentUserTurns = chatHistory
    .filter(m => m.sender === 'user')
    .slice(-3)
    .map(m => m.text)
    .join(' | ');

  const recentAssistantTurns = chatHistory
    .filter(m => m.sender !== 'user')
    .slice(-2)
    .map(m => m.text)
    .join(' | ');

  return `\nSESSION STATE (for anti-loop):\n- Recent student messages (last 3): ${recentUserTurns || '(none)'}\n- Recent teacher messages (last 2): ${recentAssistantTurns || '(none)'}\n- Reminder: do not repeat the same social reply; redirect with a micro-task.`;
};

// ————————————————————————————————————————————————————————————————————————————
// Core response function (Text only)
// ————————————————————————————————————————————————————————————————————————————
const getOpenAIResponse = async (message, chatHistory = [], topic = null, userInfo = null, isFollowUp = false) => {
  try {
    const openaiClient = initializeOpenAI();

    const isAutoPrompt = message.includes('[AUTO_PROMPT]');
    const topicId = getTopicId(topic);
    const topicPrompt = TOPIC_PROMPTS[topicId];

    // Engagement level & voice preset for this turn
    const level = estimateEngagementLevel({ message, chatHistory, isAutoPrompt });
    const voicePreset = pickVoiceForLevel(level);

    // Construct system prompt
    let systemPrompt;
    if (isAutoPrompt) {
      const reengageBlock = `\nIMPORTANT: The student hasn't responded for 30 seconds. You are in [LEVEL:REENGAGE].\n- Use one playful line.\n- Give a tiny game immediately (A/B or say 2 words).\n- Short and exciting. Positive reinforcement.`;
      if (topicPrompt) {
        systemPrompt = replacePromptPlaceholders(topicPrompt.prompt, userInfo) + buildSessionStateBlock(chatHistory) + reengageBlock;
      } else {
        systemPrompt = `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}${buildSessionStateBlock(chatHistory)}${reengageBlock}\n\nStudent:\n- Name: ${userInfo?.name || 'Student'}\n- Age: ${userInfo?.age || 'Unknown'}\n\nTopic: ${topic?.title || 'General English'} — ${topic?.description || 'General conversation'}`;
      }
    } else if (isFollowUp && topicId && FOLLOW_UP_PROMPTS[topicId]) {
      systemPrompt = `${FOLLOW_UP_PROMPTS[topicId]}${buildSessionStateBlock(chatHistory)}\n${LEVEL_INSTRUCTIONS}`;
    } else if (topicPrompt) {
      systemPrompt = replacePromptPlaceholders(topicPrompt.prompt, userInfo) + buildSessionStateBlock(chatHistory) + `\n${LEVEL_INSTRUCTIONS}`;
    } else {
      systemPrompt = `${BASE_RULES}\n${ANTI_LOOP_RULES}\n${LEVEL_INSTRUCTIONS}${buildSessionStateBlock(chatHistory)}\n\nStudent:\n- Name: ${userInfo?.name || 'Student'}\n- Age: ${userInfo?.age || 'Unknown'}\n\nTopic: ${topic?.title || 'General English'} — ${topic?.description || 'General conversation'}`;
    }

    // Meta cue when the user repeats the same message to nudge the model
    let userMessageForLLM = message;
    if (!isAutoPrompt && isRepeatWithin(message, chatHistory, 3)) {
      userMessageForLLM = `[REPEATED_STUDENT_MESSAGE="${message}"] The student repeated the same message. Acknowledge briefly (≤6 words) and redirect with a fresh micro-task. Avoid repeating your previous reply.`;
    }

    // Include the engagement level tag to steer the style
    const levelTag = `[LEVEL:${level}] [VOICE:${voicePreset.voice}] [STYLE:${voicePreset.style}]`;

    const messages = [
      { role: 'system', content: systemPrompt },
      ...chatHistory.map(entry => ({
        role: entry.sender === 'user' ? 'user' : 'assistant',
        content: entry.text,
      })),
      { role: 'user', content: `${levelTag}\n${userMessageForLLM}` },
    ];

    // Logging
    console.log('\n========== OPENAI REQUEST ==========');
    console.log('Timestamp:', new Date().toISOString());
    console.log('Model: gpt-3.5-turbo');
    console.log('Topic ID:', topicId);
    console.log('Is Follow-up:', isFollowUp);
    console.log('Is Auto-prompt:', isAutoPrompt);
    console.log('Engagement Level:', level);
    console.log('Voice Preset:', voicePreset);
    console.log('\nMessages sent to OpenAI:');
    console.log(JSON.stringify(messages, null, 2));
    console.log('====================================\n');

    const completion = await openaiClient.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages,
      max_tokens: 180,           // keep it short for kids + mobile
      temperature: level === ENGAGEMENT_LEVEL.CHALLENGE ? 0.8 : 0.7, // a bit more creative in CHALLENGE
      presence_penalty: 0.2,     // mild variety
      frequency_penalty: 0.3,    // discourage repetition
    });

    const textResponse = completion.choices[0].message.content;

    console.log('\n========== OPENAI RESPONSE ==========');
    console.log('Timestamp:', new Date().toISOString());
    console.log('Response ID:', completion.id);
    console.log('Model:', completion.model);
    console.log('Tokens Used - Prompt:', completion.usage?.prompt_tokens);
    console.log('Tokens Used - Completion:', completion.usage?.completion_tokens);
    console.log('Tokens Used - Total:', completion.usage?.total_tokens);
    console.log('Finish Reason:', completion.choices[0].finish_reason);
    console.log('\nText Response:');
    console.log(textResponse);
    console.log('=====================================\n');

    // Return also the engagement metadata so caller can decide voice
    return {
      text: textResponse,
      audio: null,
      audioFormat: null,
      voice: voicePreset.voice,
      model: null,
      engagementLevel: level,
      style: voicePreset.style,
    };
  } catch (error) {
    console.error('OpenAI API Error:', error);
    throw new Error('Failed to get OpenAI response');
  }
};

// ————————————————————————————————————————————————————————————————————————————
// Text + Audio (TTS) wrapper
// ————————————————————————————————————————————————————————————————————————————
const getOpenAIResponseV2 = async (
  message,
  chatHistory = [],
  topic = null,
  userInfo = null,
  isFollowUp = false,
  fallbackVoice = 'alloy',
  ttsModel = 'tts-1'
) => {
  try {
    const textResult = await getOpenAIResponse(message, chatHistory, topic, userInfo, isFollowUp);
    const chosenVoice = textResult.voice || fallbackVoice;

    // Import TTS only here to avoid circular deps
    const { textToSpeech } = require('./ttsService');

    // You can map voice + style to TTS params if supported by your TTS engine
    const audioBuffer = await textToSpeech(textResult.text, chosenVoice, ttsModel, {
      style: textResult.style,
      level: textResult.engagementLevel,
    });

    return {
      text: textResult.text,
      audio: audioBuffer,
      audioFormat: 'mp3',
      voice: chosenVoice,
      model: ttsModel,
      engagementLevel: textResult.engagementLevel,
      style: textResult.style,
    };
  } catch (error) {
    console.error('OpenAI Response V2 Error:', error);
    throw new Error('Failed to get OpenAI response with audio');
  }
};

// ————————————————————————————————————————————————————————————————————————————
// Exports
// ————————————————————————————————————————————————————————————————————————————
module.exports = {
  getOpenAIResponse,
  getOpenAIResponseV2,
  TOPIC_PROMPTS,
  FOLLOW_UP_PROMPTS,
  getTopicId,
  replacePromptPlaceholders,
  // export utils for testing
  ANTI_LOOP_RULES,
  ENGAGEMENT_LEVEL,
  estimateEngagementLevel,
  isRepeatWithin,
  pickVoiceForLevel,
};
