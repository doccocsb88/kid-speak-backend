// src/services/openaiService.js — Multi-Level Engagement AI Teacher v2.1 (Options-enabled)
// Author: ChatGPT (2025-10-14)
// Description: Drop-in upgrade for v2 with client-driven OPTIONS
//  - Adds JSON-like options schema, validation & defaults
//  - Renders OPTION DIRECTIVES into system prompt + conditional constraints
//  - Maps options → OpenAI params (temperature, penalties)
//  - Maps options → TTS (voice policy, rate, ssml, pauses)
//  - Keeps anti-loop + engagement levels, backwards compatible exports

require('dotenv').config();
const OpenAI = require('openai');

// ————————————————————————————————————————————————————————————————————————————
// Initialization (lazy)
// ————————————————————————————————————————————————————————————————————————————
let openai = null;
const initializeOpenAI = () => {
  if (!openai) {
    if (!process.env.OPENAI_API_KEY) {
      throw new Error('OPENAI_API_KEY environment variable is required');
    }
    openai = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  }
  return openai;
};

// ————————————————————————————————————————————————————————————————————————————
// Options Schema (lightweight manual validation)
// NOTE: Keep keys in sync with client payload and prompt directives
// ————————————————————————————————————————————————————————————————————————————
const OPTIONS_DEFAULT = {
  // Pedagogy
  grammar_check: true,
  force_repeat: 'soft', // 'off' | 'soft' | 'strict'
  correction_mode: 'explicit', // 'implicit' | 'explicit' | 'sandwich'
  difficulty: 'auto', // 'auto' | 'starters' | 'movers' | 'flyers'
  focus: ['vocabulary', 'pronunciation'],
  target_vocab: [],
  min_examples_per_point: 1,
  scaffold_level: 1, // 0..3

  // Language shaping
  max_sentence_words: 10,
  max_sentences_per_turn: 2,
  emoji_usage: 'light', // 'off' | 'light' | 'medium'
  bilingual_support: 'off', // 'off' | 'keyword_gloss' | 'brief_hint'
  ipa_pronunciation: false,
  phonics_hints: false,

  // Engagement & game mechanics
  anti_loop: true,
  reengage_after_seconds: 30,
  reengage_style: 'playful', // 'playful' | 'calm' | 'quiz'
  activity_preference: ['repeat_after_me', 'AB_choice', 'fill_blank'],
  praise_frequency: 'normal', // 'low' | 'normal' | 'high'
  challenge_ratio: 0.4,

  // Flow & topic control
  topic_strictness: 'normal', // 'loose' | 'normal' | 'strict'
  open_question_ratio: 0.3, // 0..1
  wrap_up_on_turns: 14,

  // Safety & content
  banned_topics: [],
  profanity_filter: true,
  age_gate: 6,

  // Model params
  temperature_base: 0.6,
  frequency_penalty: 0.4,
  presence_penalty: 0.2,

  // Voice (TTS wrappers use these)
  voice_policy: 'per_level', // or 'fixed'
  voice_fixed: 'sparkle',
  speaking_rate: 'slow',
  pause_ms_between_sentences: 300,
};

const ENUMS = {
  force_repeat: ['off', 'soft', 'strict'],
  correction_mode: ['implicit', 'explicit', 'sandwich'],
  difficulty: ['auto', 'starters', 'movers', 'flyers'],
  focus: ['vocabulary', 'pronunciation', 'grammar', 'listening', 'speaking'],
  emoji_usage: ['off', 'light', 'medium'],
  bilingual_support: ['off', 'keyword_gloss', 'brief_hint'],
  voice_policy: ['per_level', 'fixed'],
  speaking_rate: ['slow', 'normal', 'fast'],
};

// const VALID_VOICES = ['sparkle', 'breeze', 'meadow', 'ember', 'wave'];
const VALID_VOICES = ['nova', 'shimmer', 'echo', 'onyx', 'fable', 'alloy', 'ash', 'sage', 'coral'];


const clamp = (num, min, max) => Math.min(max, Math.max(min, num));

const sanitizeOptions = (raw) => {
  const out = { ...OPTIONS_DEFAULT };
  if (!raw || typeof raw !== 'object') return out;

  // helper to set enum
  const pickEnum = (key, value) => (ENUMS[key]?.includes(value) ? value : OPTIONS_DEFAULT[key]);

  // copy with guards
  if (typeof raw.grammar_check === 'boolean') out.grammar_check = raw.grammar_check;
  if (raw.force_repeat) out.force_repeat = pickEnum('force_repeat', raw.force_repeat);
  if (raw.correction_mode) out.correction_mode = pickEnum('correction_mode', raw.correction_mode);
  if (raw.difficulty) out.difficulty = pickEnum('difficulty', raw.difficulty);
  if (Array.isArray(raw.focus)) out.focus = raw.focus.filter((f) => ENUMS.focus.includes(f));
  if (Array.isArray(raw.target_vocab)) out.target_vocab = raw.target_vocab.map(String).slice(0, 64);
  if (Number.isFinite(raw.min_examples_per_point)) out.min_examples_per_point = clamp(raw.min_examples_per_point, 0, 10);
  if (Number.isInteger(raw.scaffold_level)) out.scaffold_level = clamp(raw.scaffold_level, 0, 3);

  if (Number.isFinite(raw.max_sentence_words)) out.max_sentence_words = clamp(raw.max_sentence_words, 4, 20);
  if (Number.isFinite(raw.max_sentences_per_turn)) out.max_sentences_per_turn = clamp(raw.max_sentences_per_turn, 1, 4);
  if (raw.emoji_usage) out.emoji_usage = pickEnum('emoji_usage', raw.emoji_usage);
  if (raw.bilingual_support) out.bilingual_support = pickEnum('bilingual_support', raw.bilingual_support);
  if (typeof raw.ipa_pronunciation === 'boolean') out.ipa_pronunciation = raw.ipa_pronunciation;
  if (typeof raw.phonics_hints === 'boolean') out.phonics_hints = raw.phonics_hints;

  if (typeof raw.anti_loop === 'boolean') out.anti_loop = raw.anti_loop;
  if (Number.isFinite(raw.reengage_after_seconds)) out.reengage_after_seconds = clamp(raw.reengage_after_seconds, 10, 180);
  if (raw.reengage_style) out.reengage_style = raw.reengage_style;
  if (Array.isArray(raw.activity_preference)) out.activity_preference = raw.activity_preference.slice(0, 8);

  if (raw.topic_strictness) out.topic_strictness = pickEnum('topic_strictness', raw.topic_strictness) || 'normal';
  if (Number.isFinite(raw.open_question_ratio)) out.open_question_ratio = clamp(raw.open_question_ratio, 0, 1);
  if (Number.isInteger(raw.wrap_up_on_turns)) out.wrap_up_on_turns = clamp(raw.wrap_up_on_turns, 5, 40);

  if (Array.isArray(raw.banned_topics)) out.banned_topics = raw.banned_topics.map(String).slice(0, 32);
  if (typeof raw.profanity_filter === 'boolean') out.profanity_filter = raw.profanity_filter;
  if (Number.isFinite(raw.age_gate)) out.age_gate = clamp(raw.age_gate, 4, 12);

  if (Number.isFinite(raw.temperature_base)) out.temperature_base = clamp(raw.temperature_base, 0, 2);
  if (Number.isFinite(raw.frequency_penalty)) out.frequency_penalty = clamp(raw.frequency_penalty, -2, 2);
  if (Number.isFinite(raw.presence_penalty)) out.presence_penalty = clamp(raw.presence_penalty, -2, 2);

  if (raw.voice_policy) out.voice_policy = pickEnum('voice_policy', raw.voice_policy);
  if (raw.voice_fixed && VALID_VOICES.includes(raw.voice_fixed)) out.voice_fixed = raw.voice_fixed;
  if (raw.speaking_rate) out.speaking_rate = pickEnum('speaking_rate', raw.speaking_rate);
  if (Number.isFinite(raw.pause_ms_between_sentences)) out.pause_ms_between_sentences = clamp(raw.pause_ms_between_sentences, 100, 1000);

  return out;
};

// ————————————————————————————————————————————————————————————————————————————
// Utilities
// ————————————————————————————————————————————————————————————————————————————
const normalize = (s = '') =>
  s
    .toLowerCase()
    .normalize('NFKD')
    .replace(/[^\w\s\-]/g, '')
    .replace(/\s+/g, ' ')
    .trim();

const SIMPLIFY_MAP = [
  ['how are you', 'how are you'],
  ['hi', 'hi'],
  ['hello', 'hello'],
  ['ok', 'ok'],
  ['okay', 'ok'],
  ['yes', 'yes'],
];
const simplify = (s = '') => {
  const n = normalize(s);
  for (const [key, val] of SIMPLIFY_MAP) {
    if (n === key) return val;
  }
  return n;
};
const isRepeatWithin = (message, history, lookback = 3) => {
  const msg = simplify(message);
  const lastUser = history
    .filter((m) => m.sender === 'user')
    .slice(-lookback)
    .map((m) => simplify(m.text));
  return lastUser.includes(msg);
};
const countSocialSmallTalk = (history, lookback = 6) => {
  const smallTalkSet = new Set(['hi', 'hello', 'how are you', 'ok', 'yes']);
  return history
    .filter((m) => m.sender === 'user')
    .slice(-lookback)
    .map((m) => simplify(m.text))
    .filter((t) => smallTalkSet.has(t)).length;
};

// ————————————————————————————————————————————————————————————————————————————
// Prompt templates (abridged for this service file)
// ————————————————————————————————————————————————————————————————————————————
const BASE_RULES = (opts = OPTIONS_DEFAULT) => `
You are a kind, playful English teacher for Vietnamese kids.
Use short, simple sentences. Warm, encouraging tone — never robotic.

CRITICAL:
Continue only after they understand.

Be proactive: suggest topic activities, mini-games, songs/dialogues.
Repeat key vocabulary naturally. End each reply with a short task.
`;

const LEVEL_INSTRUCTIONS = `
LEVEL BEHAVIOR GUIDE:
- [LEVEL:WARM_UP] Greet briefly. Teach 1 tiny point. Give an easy task.
- [LEVEL:CORE] Practice target vocab/grammar. One correction max. Give a clear task.
- [LEVEL:CHALLENGE] Slightly harder task (fill-the-blank, A/B/C). Keep it fun.
- [LEVEL:REENGAGE] Very short, playful line. Immediate mini-game. No open questions.
- [LEVEL:WRAP_UP] Praise + 1-sentence summary. Tiny exit task if time.
`;

const TOPIC_PROMPTS = (opts = OPTIONS_DEFAULT) => ({
  'general-speaking': {
    ageRange: '6-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: General Speaking
Practice everyday conversations and general speaking skills.
Key vocabulary: hello, thank you, please, sorry, goodbye, how are you, nice to meet you, excuse me.
Focus on polite expressions, greetings, and basic social interactions.`,
  },
  'animals': {
    ageRange: '6-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Animals
Learn about pets, farm animals, and wild animals.
Key vocabulary: dog, cat, bird, fish, cow, pig, lion, elephant.
Talk about animal sounds, habitats, and characteristics. Use fun animal activities and games.`,
  },
  'colors': {
    ageRange: '6-8',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Colors
Discover all the beautiful colors around us.
Key vocabulary: red, blue, green, yellow, orange, purple, pink, black.
Practice identifying colors of objects, mixing colors, and describing things by their colors.`,
  },
  'family': {
    ageRange: '6-9',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Family
Meet your family members and relatives.
Key vocabulary: mother, father, sister, brother, grandmother, grandfather, baby.
Talk about family relationships, family activities, and introduce family members.`,
  },
  'food': {
    ageRange: '6-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Food
Explore delicious foods and drinks.
Key vocabulary: apple, banana, bread, milk, water, cake, pizza, rice.
Discuss favorite foods, healthy eating, meal times, and food preferences.`,
  },
  'numbers': {
    ageRange: '6-8',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Numbers
Count from 1 to 20 and learn basic math.
Key vocabulary: one, two, three, four, five, six, seven, eight, nine, ten.
Practice counting, simple addition, and number recognition through games and activities.`,
  },
  'body': {
    ageRange: '7-10',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Body Parts
Learn about your body and how to take care of it.
Key vocabulary: head, eyes, nose, mouth, hands, feet, ears, legs.
Identify body parts, discuss body functions, and learn about hygiene and health.`,
  },
  'clothes': {
    ageRange: '7-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Clothes
Dress up and learn about different clothes.
Key vocabulary: shirt, pants, dress, shoes, hat, socks, jacket, skirt.
Talk about what to wear for different occasions, weather, and personal style.`,
  },
  'weather': {
    ageRange: '8-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Weather
Talk about sunny, rainy, and snowy days.
Key vocabulary: sunny, rainy, cloudy, windy, hot, cold, warm, cool.
Describe weather conditions, seasons, and appropriate activities for different weather.`,
  },
  'school': {
    ageRange: '6-11',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: School
Learn about school, teachers, and friends.
Key vocabulary: teacher, student, book, pencil, desk, chair, classroom, playground.
Discuss school activities, subjects, classroom objects, and school life.`,
  },
  'toys': {
    ageRange: '6-9',
    prompt: `${BASE_RULES(opts)}\n${LEVEL_INSTRUCTIONS}\n\nTOPIC: Toys
Play with your favorite toys and games.
Key vocabulary: doll, ball, car, toy, game, puzzle, blocks, teddy bear.
Talk about favorite toys, how to play with them, and sharing toys with friends.`,
  },
});

const FOLLOW_UP_PROMPTS = {
  REENGAGE: `Quick playful nudge. Keep it within 1 short sentence.`,
};

const buildUserContext = (userInfo) => {
  if (!userInfo) return '';
  
  return `
STUDENT INFORMATION:
- Name: ${userInfo.name || 'Student'}
- Age: ${userInfo.age || 'Unknown'} years old

IMPORTANT: Always address the student by their name (${userInfo.name || 'Student'}) when appropriate.`;
};

const replacePromptPlaceholders = (prompt, userInfo, opts) => {
  const withNumbers = prompt
    .replace(/{{name}}/g, userInfo?.name || 'Student')
    .replace(/{{age}}/g, userInfo?.age || 'Unknown')
    .replace(/{{MAX_WORDS}}/g, String(opts.max_sentence_words))
    .replace(/{{MAX_SENTENCES}}/g, String(opts.max_sentences_per_turn));
  return withNumbers;
};

const getTopicId = (topic) => {
  if (!topic) return null;
  return topic.id || topic.title?.toLowerCase().replace(/\s+/g, '-') || null;
};

const buildSessionStateBlock = (chatHistory = []) => {
  // Keep system prompt lean: avoid duplicating assistant text (already present in history).
  // Only include a concise user-side reminder for context.
  const lastUser = (chatHistory.filter(m => m.sender === 'user').slice(-1)[0]?.text || '').trim();
  const smallTalkCount = countSocialSmallTalk(chatHistory, 6);
  const hint = smallTalkCount >= 3 ? 'Student tends to small-talk; steer gently back to topic.' : '';
  return `\nSESSION STATE:\n- Last student message: ${lastUser || '(none)'}\n- Note: ${hint}`;
};

const renderOptionDirectives = (opts) => {
  return [
    `Education level: ${opts.difficulty}. Focus: ${opts.focus.join(', ')}`,
    `Correction mode: ${opts.correction_mode}; Repeat policy: ${opts.force_repeat}`,
    `Emoji usage: ${opts.emoji_usage}; Bilingual: ${opts.bilingual_support}; IPA: ${opts.ipa_pronunciation ? 'on' : 'off'}; Phonics: ${opts.phonics_hints ? 'on' : 'off'}`,
    `Topic strictness: ${opts.topic_strictness}`,
    'Violations not allowed.',
  ].join('\n');
};

const buildConditionalConstraints = (opts) => {
  const lines = [];
  if (!opts.grammar_check) lines.push('Skip grammar correction unless a severe misunderstanding occurs.');
  if (opts.force_repeat === 'off') lines.push('Do not force the student to repeat after corrections.');
  if (opts.force_repeat === 'soft') lines.push('After a correction, encourage a repeat once, but do not insist.');
  if (opts.force_repeat === 'strict') lines.push('After any correction, always ask the student to repeat exactly once.');

  if (opts.emoji_usage === 'off') lines.push('Do not use emojis.');
  if (opts.emoji_usage === 'light') lines.push('Use at most one emoji per reply.');
  if (opts.emoji_usage === 'medium') lines.push('Use up to two emojis per reply.');

  if (opts.bilingual_support === 'keyword_gloss') lines.push('After new words, add a one-word Vietnamese gloss in parentheses.');
  if (opts.bilingual_support === 'brief_hint') lines.push('Add one brief Vietnamese hint when necessary. Keep English first.');

  if (opts.ipa_pronunciation) lines.push('Add IPA notation for tricky words sparingly.');
  if (opts.phonics_hints) lines.push('Add simple phonics hints (e.g., "dr- = /dr/").');

  if (opts.topic_strictness === 'strict') lines.push('Do not accept off-topic replies; redirect with a short on-topic task.');
  if (opts.topic_strictness === 'loose') lines.push('Allow light tangents, but return to topic with a task.');

  if (opts.profanity_filter) lines.push('Avoid any profanity or age-inappropriate content.');
  if (opts.banned_topics.length > 0) lines.push(`Avoid these topics entirely: ${opts.banned_topics.join(', ')}.`);

  lines.push(`Keep each reply ≤ ${opts.max_sentences_per_turn} sentence(s), each sentence ≤ ${opts.max_sentence_words} words.`);
  lines.push(`Mix open questions (${Math.round(opts.open_question_ratio * 100)}%) with activities: ${opts.activity_preference.join(', ')}.`);
  lines.push(`Aim to wrap up around turn ${opts.wrap_up_on_turns} with a brief summary and exit task.`);

  return lines.join('\n');
};

// Helper: prevent repeating the same activity pattern back-to-back based on recent assistant outputs
const buildAssistantPatternRotateConstraint = (chatHistory = []) => {
  const recentAssistant = chatHistory.filter(m => m.sender !== 'user').slice(-2).map(m => (m.text || '').toLowerCase()).join(' || ');
  const avoid = [];
  if (/choose:\s*a\)/.test(recentAssistant) || /\ba\)\s|\bb\)\s|\bc\)\s/.test(recentAssistant)) {
    avoid.push('Avoid AB_choice this turn.');
  }
  if (/repeat after me/.test(recentAssistant)) {
    avoid.push('Avoid repeat_after_me this turn.');
  }
  if (/fill in the blank|____/.test(recentAssistant)) {
    avoid.push('Avoid fill_blank this turn.');
  }
  const header = 'Do not reuse the same activity pattern twice in a row. Rotate patterns.';
  return [header, ...avoid].join('\n');
};

// ————————————————————————————————————————————————————————————————————————————
// Core response function (Text only)
// ————————————————————————————————————————————————————————————————————————————
const ENGAGEMENT_LEVEL = {
  WARM_UP: 'WARM_UP',
  CORE: 'CORE',
  CHALLENGE: 'CHALLENGE',
  REENGAGE: 'REENGAGE',
  WRAP_UP: 'WRAP_UP',
};

const pickVoiceForLevel = (level, opts) => {
  if (opts.voice_policy === 'fixed') return { voice: opts.voice_fixed, style: 'default' };
  switch (level) {
    case ENGAGEMENT_LEVEL.WARM_UP: return { voice: 'shimmer', style: 'soft-friendly' };
    case ENGAGEMENT_LEVEL.CORE: return { voice: 'alloy', style: 'clear-slow' };
    case ENGAGEMENT_LEVEL.CHALLENGE: return { voice: 'nova', style: 'energetic' };
    case ENGAGEMENT_LEVEL.REENGAGE: return { voice: 'echo', style: 'playful' };
    case ENGAGEMENT_LEVEL.WRAP_UP: return { voice: 'alloy', style: 'warm-summary' };
    default: return { voice: 'meadow', style: 'friendly' };
  }
};

const estimateEngagementLevel = (chatHistory = [], opts) => {
  const lastAssistant = chatHistory.filter(m => m.sender !== 'user').slice(-1)[0]?.text || '';
  const wasChallenge = /\[LEVEL:CHALLENGE\]/.test(lastAssistant);
  const turns = chatHistory.length;

  if (turns >= opts.wrap_up_on_turns) return ENGAGEMENT_LEVEL.WRAP_UP;

  if (wasChallenge) return ENGAGEMENT_LEVEL.CORE;

  const idleReengage = false; // gate from caller if needed
  if (idleReengage) return ENGAGEMENT_LEVEL.REENGAGE;

  return Math.random() < opts.challenge_ratio ? ENGAGEMENT_LEVEL.CHALLENGE : ENGAGEMENT_LEVEL.CORE;
};

const ANTI_LOOP_RULES = `
ANTI-LOOP RULES:
- If the student repeats a message, do NOT mirror the same reply. Switch activity or use a different wording.
- Do not repeat the same assistant pattern twice (A/B choice, "repeat after me", fill-in-the-blank).
- Vary praise phrases and tasks.
`;

// ————————————————————————————————————————————————————————————————————————————
// Core response function (Text only)
// ————————————————————————————————————————————————————————————————————————————
const getOpenAIResponse = async (
  message,
  chatHistory = [],
  topic = null,
  userInfo = null,
  isFollowUp = false,
  options = null // NEW: client-provided options
) => {
  try {
    const openaiClient = initializeOpenAI();

    // Validate/merge options
    const opts = sanitizeOptions(options);

    const isAutoPrompt = typeof message === 'string' && message.includes('[AUTO_PROMPT]');
    const level = estimateEngagementLevel(chatHistory, opts);
    const { voice: chosenVoice, style: chosenStyle } = pickVoiceForLevel(level, opts);

    // Build base prompt pieces
    console.log('[openaiService] ========== PROCESSING TOPIC ==========');
    console.log('[openaiService] typeof topic:', typeof topic);
    console.log('[openaiService] topic:', topic);
    console.log('[openaiService] topic?.id:', topic?.id);
    console.log('[openaiService] topic?.title:', topic?.title);
    
    // Ensure topic is an object (should always be at this point)
    if (typeof topic === 'string') {
      console.error('[openaiService] ⚠️ WARNING: Topic is still a string! This should not happen.');
      console.log('[openaiService] Topic string value:', topic);
    }
    
    const topicId = getTopicId(topic);
    console.log('[openaiService] Extracted topicId:', topicId);
    console.log('[openaiService] =========================================');
    const topicPromptsObj = TOPIC_PROMPTS(opts);
    const topicPrompt = topic?.id && topicPromptsObj[topic.id]?.prompt ? topicPromptsObj[topic.id].prompt : BASE_RULES(opts);
    const base = replacePromptPlaceholders(topicPrompt, userInfo, {
      max_sentence_words: opts.max_sentence_words,
      max_sentences_per_turn: opts.max_sentences_per_turn,
    });
    const userContext = buildUserContext(userInfo); // NEW: Add user context
    const levelGuide = LEVEL_INSTRUCTIONS;
    const sessionState = buildSessionStateBlock(chatHistory);
    const antiLoop = opts.anti_loop ? `\n${ANTI_LOOP_RULES}` : '';
    const optionDirectives = renderOptionDirectives(opts);
    const conditionalConstraints = buildConditionalConstraints(opts);

    let reengageBlock = '';
    if (isAutoPrompt) {
      reengageBlock = `\nIMPORTANT: The student hasn't responded for ${opts.reengage_after_seconds}s. Reengage with 1 playful micro-game (A/B or say 2 words).\n- Be exciting. Positive reinforcement.`;
    }

    const rotateConstraint = buildAssistantPatternRotateConstraint(chatHistory);

    const outputContract = [
      'OUTPUT CONTRACT:',
      `- Exactly ${opts.max_sentences_per_turn} sentence(s).`,
      `- Each sentence ≤ ${opts.max_sentence_words} words.`,
      '- End with a concrete task.',
      '- If you violate any rule, rewrite once until all pass.',
      'Return only the final, corrected line.'
    ].join('\n');

    // Compose final system prompt
    const systemPrompt = [
      base,
      userContext, // NEW: Include user context in system prompt
      antiLoop,
      levelGuide,
      sessionState,
      optionDirectives,
      'CONDITIONAL CONSTRAINTS:',
      conditionalConstraints,
      rotateConstraint,
      outputContract,
      '— End of teacher rules —'
      // reengageBlock,
    ].join('\n');

    // Build messages array - check if current message is already in chatHistory to avoid duplication
    const lastHistoryMessage = chatHistory.length > 0 ? chatHistory[chatHistory.length - 1] : null;
    const isMessageAlreadyInHistory = lastHistoryMessage && 
                                       lastHistoryMessage.sender === 'user' && 
                                       lastHistoryMessage.text === message;
    
    const messages = [
      { role: 'system', content: systemPrompt },
      ...chatHistory.map((entry) => ({
        role: entry.sender === 'user' ? 'user' : 'assistant',
        content: entry.text,
      })),
      // Only add current message if it's not already the last item in chatHistory
      ...(isMessageAlreadyInHistory ? [] : [{ role: 'user', content: message }]),
    ];

    // Logging (include options for debugging)
    console.log('\n========== OPENAI REQUEST ==========');
    console.log('Timestamp:', new Date().toISOString());
    console.log('Model:', 'gpt-3.5-turbo');
    console.log('Topic ID:', topicId);
    console.log('Is Follow-up:', isFollowUp);
    console.log('Is Auto-prompt:', isAutoPrompt);
    console.log('Engagement Level:', level);
    console.log('Voice:', chosenVoice, 'Style:', chosenStyle);
    console.log('Last applied options:', JSON.stringify(opts, null, 2));
    console.log('\nMessages sent to OpenAI:');
    console.log(JSON.stringify(messages, null, 2));
    console.log('====================================\n');

    const completion = await openaiClient.chat.completions.create({
      model: 'gpt-3.5-turbo',
      messages,
      max_tokens: 180, // short for kids + mobile
      temperature: level === ENGAGEMENT_LEVEL.CHALLENGE ? Math.min(1.2, opts.temperature_base + 0.1) : opts.temperature_base,
      presence_penalty: opts.presence_penalty,
      frequency_penalty: opts.frequency_penalty,
    });

    const textResponse = completion.choices[0].message.content;

    console.log('\n========== OPENAI RESPONSE ==========');
    console.log('Timestamp:', new Date().toISOString());
    console.log('Response ID:', completion.id);
    console.log('Model:', completion.model);
    console.log('Tokens Used - Prompt:', completion.usage?.prompt_tokens);
    console.log('Tokens Used - Completion:', completion.usage?.completion_tokens);
    console.log('Tokens Used - Total:', completion.usage?.total_tokens);
    console.log('Finish Reason:', completion.choices[0].finish_reason);
    console.log('\nText Response:');
    console.log(textResponse);
    console.log('Engagement Level:', level);
    console.log('=====================================\n');

    return {
      text: textResponse, // Clean text without level tags
      audio: null,
      audioFormat: null,
      voice: chosenVoice,
      meta: {
        level,
        style: chosenStyle,
      },
    };
  } catch (err) {
    console.error('[openaiService] Error:', err);
    throw err;
  }
};

// ————————————————————————————————————————————————————————————————————————————
// V2 Response function (with integrated TTS)
// ————————————————————————————————————————————————————————————————————————————
const getOpenAIResponseV2 = async (
  message,
  chatHistory = [],
  topic = null,
  userInfo = null,
  isFollowUp = false,
  voice = 'alloy', // fallback voice, will be overridden by pickVoiceForLevel
  model = 'gpt-4o-mini-tts', // NEW: Default to gpt-4o-mini-tts for instructions support
  options = null
) => {
  try {
    // Get text response from the main function (includes voice selection via pickVoiceForLevel)
    const textResponse = await getOpenAIResponse(message, chatHistory, topic, userInfo, isFollowUp, options);
    
    // Import TTS service here to avoid circular dependency issues
    const { textToSpeech } = require('./ttsService');
    
    // Use the voice determined by pickVoiceForLevel (from options and engagement level)
    const selectedVoice = textResponse.voice || voice;
    
    // Sanitize options for TTS
    const opts = sanitizeOptions(options);
    
    // Generate audio from the clean text using the selected voice and full context
    const audioBuffer = await textToSpeech(textResponse.text, selectedVoice, model, {
      conversationOptions: opts, // Pass sanitized options for TTS instructions
      engagementLevel: textResponse.meta?.level || 'CORE',
      style: textResponse.meta?.style || 'default',
    });
    
    return {
      text: textResponse.text,
      audio: audioBuffer,
      audioFormat: 'mp3',
      voice: selectedVoice,
      model: model,
      engagementLevel: textResponse.meta?.level || 'CORE',
      style: textResponse.meta?.style || 'default',
      options: options
    };
  } catch (err) {
    console.error('[openaiService] Error in getOpenAIResponseV2:', err);
    throw err;
  }
};

module.exports = {
  getOpenAIResponse,
  getOpenAIResponseV2,
  // Expose some pieces for testing / external orchestration
  TOPIC_PROMPTS,
  FOLLOW_UP_PROMPTS,
  getTopicId,
  replacePromptPlaceholders,
  buildUserContext,
  ANTI_LOOP_RULES,
  ENGAGEMENT_LEVEL,
  estimateEngagementLevel,
  isRepeatWithin,
  pickVoiceForLevel,
  // NEW exports
  sanitizeOptions,
  OPTIONS_DEFAULT,
  VALID_VOICES,
};
